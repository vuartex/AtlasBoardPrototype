using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class TabletUIManager : MonoBehaviour
{
    [Header("Tablet Shell")]
    [SerializeField]
    private GameObject backdropDim;

    [SerializeField]
    private GameObject tabletRoot;

    [SerializeField]
    private TMP_Text tabletTitleText;

    [Header("Tablet Panels")]
    [SerializeField]
    private GameObject purchasePanel;

    [SerializeField]
    private GameObject auctionPanel;

    [SerializeField]
    private GameObject tradePanel;

    [SerializeField]
    private GameObject eventPanel;

    [SerializeField]
    private GameObject specialResultPanel;

    [SerializeField]
    private GameObject doublesPenaltyPanel;

    [SerializeField]
    private GameObject travelPanel;

    [SerializeField]
    private GameObject developmentPanel;

    [SerializeField]
    private GameObject matchResultPanel;

    [Header("Online Seat Notice (runtime-built fallback)")]
    [SerializeField]
    private GameObject onlineSeatNoticePanel;

    private TMP_Text onlineSeatNoticeText;
    private Button onlineSeatNoticeOkButton;
    private Coroutine onlineSeatNoticeRoutine;
    private GameObject currentPanel;
    private GameObject[] gameplayPanels;
    private bool[] gameplayPanelWasActive;

    public bool IsGameplayOverlayVisible =>
        (tabletRoot != null && tabletRoot.activeInHierarchy) ||
        (currentPanel != null && currentPanel.activeInHierarchy);

    private void Awake()
    {
        AtlasBoardLocalizationManager.LanguageChanged +=
            HandleLanguageChanged;

        InitializeGameplayPanelTracking();
        RefreshLegacyStaticTabletLocalization();
        HideTabletShell();
    }

    private void OnEnable()
    {
        currentPanel = null;
        ResetGameplayPanelTracking(
            captureCurrentState: false);
    }

    private void OnDestroy()
    {
        AtlasBoardLocalizationManager.LanguageChanged -=
            HandleLanguageChanged;
    }

    private void HandleLanguageChanged()
    {
        RefreshLegacyStaticTabletLocalization();

        if (currentPanel != null)
        {
            UpdateTabletTitle(
                currentPanel);
        }
    }

    private void LateUpdate()
    {
        GameObject requestedPanel =
            FindRequestedPanel();

        if (requestedPanel == null)
        {
            currentPanel = null;
            HideTabletShell();
            return;
        }

        if (currentPanel != requestedPanel)
        {
            currentPanel = requestedPanel;
            RefreshLegacyStaticTabletLocalization();
        }

        // Some legacy managers still touch the shared header. Keep the
        // canonical title authoritative, but only write when the value differs.
        UpdateTabletTitle(
            currentPanel);

        ShowTabletShell();
    }

    public void ResetForNewMatchSession()
    {
        HideOnlineSeatNotice();

        GameObject[] panels =
        {
            purchasePanel,
            auctionPanel,
            tradePanel,
            eventPanel,
            specialResultPanel,
            doublesPenaltyPanel,
            travelPanel,
            developmentPanel,
            matchResultPanel
        };

        foreach (GameObject panel in panels)
        {
            if (panel != null)
            {
                panel.SetActive(false);
            }
        }

        currentPanel = null;
        ResetGameplayPanelTracking();
        HideTabletShell();

        if (onlineSeatNoticeText != null)
        {
            onlineSeatNoticeText.text = string.Empty;
        }
    }

    public void ShowOnlineSeatNotice(
        string message,
        float autoHideSeconds = 3f)
    {
        EnsureOnlineSeatNoticePanel();

        if (onlineSeatNoticePanel == null)
        {
            return;
        }

        if (onlineSeatNoticeText != null)
        {
            onlineSeatNoticeText.text =
                message ?? string.Empty;
        }

        onlineSeatNoticePanel.SetActive(true);

        if (onlineSeatNoticeRoutine != null)
        {
            StopCoroutine(onlineSeatNoticeRoutine);
            onlineSeatNoticeRoutine = null;
        }

        if (autoHideSeconds > 0f)
        {
            onlineSeatNoticeRoutine =
                StartCoroutine(
                    HideOnlineSeatNoticeAfter(
                        autoHideSeconds));
        }
    }

    public void HideOnlineSeatNotice()
    {
        if (onlineSeatNoticeRoutine != null)
        {
            StopCoroutine(onlineSeatNoticeRoutine);
            onlineSeatNoticeRoutine = null;
        }

        if (onlineSeatNoticePanel != null)
        {
            onlineSeatNoticePanel.SetActive(false);
        }
    }

    private IEnumerator HideOnlineSeatNoticeAfter(
        float seconds)
    {
        yield return new WaitForSecondsRealtime(
            Mathf.Max(0.25f, seconds));

        onlineSeatNoticeRoutine = null;

        if (onlineSeatNoticePanel != null)
        {
            onlineSeatNoticePanel.SetActive(false);
        }
    }

    private void EnsureOnlineSeatNoticePanel()
    {
        if (onlineSeatNoticePanel != null ||
            tabletRoot == null)
        {
            return;
        }

        GameObject panel =
            new GameObject(
                "Panel_OnlineSeatNotice",
                typeof(RectTransform),
                typeof(Image));

        panel.transform.SetParent(
            tabletRoot.transform,
            false);

        RectTransform rect =
            panel.GetComponent<RectTransform>();
        rect.anchorMin = new Vector2(0.06f, 0.08f);
        rect.anchorMax = new Vector2(0.94f, 0.86f);
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;

        Image background = panel.GetComponent<Image>();
        background.color =
            new Color(0.02f, 0.055f, 0.06f, 0.98f);

        GameObject textObject =
            new GameObject(
                "Text_OnlineSeatNotice",
                typeof(RectTransform),
                typeof(TextMeshProUGUI));
        textObject.transform.SetParent(panel.transform, false);

        RectTransform textRect =
            textObject.GetComponent<RectTransform>();
        textRect.anchorMin = new Vector2(0.08f, 0.24f);
        textRect.anchorMax = new Vector2(0.92f, 0.88f);
        textRect.offsetMin = Vector2.zero;
        textRect.offsetMax = Vector2.zero;

        onlineSeatNoticeText =
            textObject.GetComponent<TextMeshProUGUI>();
        onlineSeatNoticeText.alignment =
            TextAlignmentOptions.Center;
        onlineSeatNoticeText.fontSize = 24f;
        onlineSeatNoticeText.enableAutoSizing = true;
        onlineSeatNoticeText.fontSizeMin = 14f;
        onlineSeatNoticeText.fontSizeMax = 26f;
        onlineSeatNoticeText.color = Color.white;

        GameObject buttonObject =
            new GameObject(
                "Button_OnlineSeatNoticeOK",
                typeof(RectTransform),
                typeof(Image),
                typeof(Button));
        buttonObject.transform.SetParent(panel.transform, false);

        RectTransform buttonRect =
            buttonObject.GetComponent<RectTransform>();
        buttonRect.anchorMin = new Vector2(0.36f, 0.06f);
        buttonRect.anchorMax = new Vector2(0.64f, 0.20f);
        buttonRect.offsetMin = Vector2.zero;
        buttonRect.offsetMax = Vector2.zero;

        buttonObject.GetComponent<Image>().color =
            new Color(0.18f, 0.48f, 0.62f, 1f);

        onlineSeatNoticeOkButton =
            buttonObject.GetComponent<Button>();
        onlineSeatNoticeOkButton.onClick.AddListener(
            HideOnlineSeatNotice);

        GameObject labelObject =
            new GameObject(
                "Text_OK",
                typeof(RectTransform),
                typeof(TextMeshProUGUI));
        labelObject.transform.SetParent(buttonObject.transform, false);

        RectTransform labelRect =
            labelObject.GetComponent<RectTransform>();
        labelRect.anchorMin = Vector2.zero;
        labelRect.anchorMax = Vector2.one;
        labelRect.offsetMin = Vector2.zero;
        labelRect.offsetMax = Vector2.zero;

        TMP_Text label =
            labelObject.GetComponent<TextMeshProUGUI>();
        label.alignment = TextAlignmentOptions.Center;
        label.fontSize = 20f;
        label.color = Color.white;
        label.text = "OK";

        onlineSeatNoticePanel = panel;
        onlineSeatNoticePanel.SetActive(false);
    }

    private void RefreshLegacyStaticTabletLocalization()
    {
        if (tradePanel != null)
        {
            SetNamedText(
                tradePanel,
                "Text_TradeTargetLabel",
                AtlasBoardL.R(
                    "TRADE WITH",
                    "TAKAS YAPILACAK OYUNCU",
                    "INTERCAMBIAR CON",
                    "ÉCHANGER AVEC",
                    "HANDEL MIT",
                    "거래 상대",
                    "ОБМЕН С"));

            SetNamedText(
                tradePanel,
                "Text_TradeOfferHeader",
                AtlasBoardL.R(
                    "YOU GIVE",
                    "SEN VERİRSİN",
                    "TÚ DAS",
                    "VOUS DONNEZ",
                    "DU GIBST",
                    "내가 주는 것",
                    "ВЫ ОТДАЁТЕ"));

            SetNamedText(
                tradePanel,
                "Text_TradeRequestHeader",
                AtlasBoardL.R(
                    "OTHER PLAYER GIVES",
                    "KARŞI OYUNCU VERİR",
                    "EL OTRO JUGADOR DA",
                    "L’AUTRE JOUEUR DONNE",
                    "ANDERER SPIELER GIBT",
                    "상대가 주는 것",
                    "ДРУГОЙ ИГРОК ОТДАЁТ"));

            string cashPlaceholder =
                AtlasBoardL.R(
                    "Cash amount",
                    "Nakit miktarı",
                    "Cantidad de efectivo",
                    "Montant en espèces",
                    "Bargeldbetrag",
                    "현금 금액",
                    "Сумма наличных");

            SetNamedInputPlaceholder(
                tradePanel,
                "Input_TradeOfferedCash",
                cashPlaceholder);

            SetNamedInputPlaceholder(
                tradePanel,
                "Input_TradeRequestedCash",
                cashPlaceholder);
        }
    }

    private static void SetNamedText(
        GameObject root,
        string objectName,
        string value)
    {
        Transform child =
            FindChildRecursive(
                root != null
                    ? root.transform
                    : null,
                objectName);

        TMP_Text text =
            child != null
                ? child.GetComponent<TMP_Text>()
                : null;

        if (text != null)
        {
            text.text =
                value ?? string.Empty;
        }
    }

    private static void SetNamedInputPlaceholder(
        GameObject root,
        string objectName,
        string value)
    {
        Transform child =
            FindChildRecursive(
                root != null
                    ? root.transform
                    : null,
                objectName);

        TMP_InputField input =
            child != null
                ? child.GetComponent<TMP_InputField>()
                : null;

        if (input != null &&
            input.placeholder is TMP_Text placeholder)
        {
            placeholder.text =
                value ?? string.Empty;
        }
    }

    private static Transform FindChildRecursive(
        Transform root,
        string objectName)
    {
        if (root == null ||
            string.IsNullOrWhiteSpace(
                objectName))
        {
            return null;
        }

        if (string.Equals(
                root.name,
                objectName,
                System.StringComparison.Ordinal))
        {
            return root;
        }

        for (int index = 0;
             index < root.childCount;
             index++)
        {
            Transform found =
                FindChildRecursive(
                    root.GetChild(index),
                    objectName);

            if (found != null)
            {
                return found;
            }
        }

        return null;
    }

    private GameObject FindRequestedPanel()
    {
        GameObject gameplayPanel =
            ResolveCanonicalGameplayPanel();

        // Seat lifecycle notice is an overlay, not another gameplay decision
        // owner. It may temporarily cover the canonical gameplay panel without
        // destroying that decision state.
        if (IsPanelRequested(onlineSeatNoticePanel))
        {
            return onlineSeatNoticePanel;
        }

        return gameplayPanel;
    }

    private void InitializeGameplayPanelTracking()
    {
        gameplayPanels = new[]
        {
            purchasePanel,
            auctionPanel,
            tradePanel,
            eventPanel,
            specialResultPanel,
            doublesPenaltyPanel,
            travelPanel,
            developmentPanel,
            matchResultPanel
        };

        gameplayPanelWasActive =
            new bool[gameplayPanels.Length];

        ResetGameplayPanelTracking();
    }

    private void ResetGameplayPanelTracking(
        bool captureCurrentState = true)
    {
        if (gameplayPanels == null ||
            gameplayPanelWasActive == null ||
            gameplayPanels.Length != gameplayPanelWasActive.Length)
        {
            return;
        }

        for (int index = 0;
             index < gameplayPanels.Length;
             index++)
        {
            gameplayPanelWasActive[index] =
                captureCurrentState &&
                IsPanelRequested(
                    gameplayPanels[index]);
        }
    }

    private GameObject ResolveCanonicalGameplayPanel()
    {
        if (gameplayPanels == null ||
            gameplayPanelWasActive == null ||
            gameplayPanels.Length != gameplayPanelWasActive.Length)
        {
            InitializeGameplayPanelTracking();
        }

        GameObject risingPanel = null;
        GameObject firstActivePanel = null;

        for (int index = 0;
             index < gameplayPanels.Length;
             index++)
        {
            GameObject panel =
                gameplayPanels[index];
            bool active =
                IsPanelRequested(panel);

            if (active &&
                firstActivePanel == null)
            {
                firstActivePanel = panel;
            }

            if (active &&
                !gameplayPanelWasActive[index] &&
                risingPanel == null)
            {
                risingPanel = panel;
            }

            gameplayPanelWasActive[index] =
                active;
        }

        GameObject selected =
            risingPanel != null
                ? risingPanel
                : IsGameplayPanel(currentPanel) &&
                  IsPanelRequested(currentPanel)
                    ? currentPanel
                    : firstActivePanel;

        if (selected == null)
        {
            return null;
        }

        int duplicatePanelsClosed = 0;

        for (int index = 0;
             index < gameplayPanels.Length;
             index++)
        {
            GameObject panel =
                gameplayPanels[index];

            if (panel == null ||
                panel == selected ||
                !panel.activeSelf)
            {
                continue;
            }

            panel.SetActive(false);
            gameplayPanelWasActive[index] = false;
            duplicatePanelsClosed++;
        }

        if (duplicatePanelsClosed > 0)
        {
            Debug.Log(
                "ATB_TABLET_OWNER duplicate_panels_closed=" +
                duplicatePanelsClosed +
                " canonical=" +
                selected.name,
                this);
        }

        return selected;
    }

    private bool IsGameplayPanel(
        GameObject panel)
    {
        if (panel == null ||
            gameplayPanels == null)
        {
            return false;
        }

        for (int index = 0;
             index < gameplayPanels.Length;
             index++)
        {
            if (gameplayPanels[index] == panel)
            {
                return true;
            }
        }

        return false;
    }

    private bool IsPanelRequested(
        GameObject panel)
    {
        return panel != null &&
               panel.activeSelf;
    }

    private void ShowTabletShell()
    {
        if (backdropDim != null &&
            !backdropDim.activeSelf)
        {
            backdropDim.SetActive(true);
        }

        if (tabletRoot != null &&
            !tabletRoot.activeSelf)
        {
            tabletRoot.SetActive(true);
        }
    }

    private void HideTabletShell()
    {
        if (backdropDim != null &&
            backdropDim.activeSelf)
        {
            backdropDim.SetActive(false);
        }

        if (tabletRoot != null &&
            tabletRoot.activeSelf)
        {
            tabletRoot.SetActive(false);
        }
    }

    private void UpdateTabletTitle(
        GameObject panel)
    {
        if (tabletTitleText == null)
        {
            return;
        }

        string desiredTitle =
            ResolveTabletTitle(panel);

        if (!string.Equals(
                tabletTitleText.text,
                desiredTitle,
                System.StringComparison.Ordinal))
        {
            tabletTitleText.text =
                desiredTitle;
        }
    }

    private string ResolveTabletTitle(
        GameObject panel)
    {
        if (panel == purchasePanel) return AtlasBoardL.T("tablet.property");
        if (panel == auctionPanel) return AtlasBoardL.T("tablet.auction");
        if (panel == tradePanel) return AtlasBoardL.T("tablet.trade");
        if (panel == eventPanel) return AtlasBoardL.T("tablet.event");
        if (panel == specialResultPanel) return AtlasBoardL.T("tablet.result");
        if (panel == doublesPenaltyPanel) return AtlasBoardL.T("tablet.penalty");
        if (panel == travelPanel) return AtlasBoardL.T("tablet.travel");
        if (panel == developmentPanel) return AtlasBoardL.T("tablet.development");
        if (panel == matchResultPanel) return AtlasBoardL.T("tablet.match_result");

        if (panel == onlineSeatNoticePanel)
        {
            return AtlasBoardL.R(
                "PLAYER STATUS",
                "OYUNCU DURUMU",
                "ESTADO DEL JUGADOR",
                "STATUT DU JOUEUR",
                "SPIELERSTATUS",
                "플레이어 상태",
                "СТАТУС ИГРОКА");
        }

        return "ATLAS BOARD";
    }
}
